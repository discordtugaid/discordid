# discordid2date
Turns a Discord ID (channel, server, user or message) into the creation date.

https://hugonun.github.io/discordid2date/

This version has no design to make it easy to implement anywhere, if you want to use it in a fancier website, go here:
https://hugo.moe/discord/discord-id-creation-date.html


